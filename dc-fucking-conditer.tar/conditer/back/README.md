# Cond Backend


## Getting Started
These instructions will help you start and run a copy of the project on your local computer for development and testing purposes.

Start with cloning this repo on your local machine:

```sh
$ cd directory
$ git clone git@gitlab.com:13lab/cond/back.git
$ cd ./{project}
```

### Installation 
To install and set up the libraries, run:
```sh    
$ npm install
```

## Usage

### Run server in dev env
```sh 
$ npm run dev
```

## Stack
- Node.js
- Express.js
- PostgreSQL
- Sequelize ORM
