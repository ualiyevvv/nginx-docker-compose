const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../../.env')});
const { Umzug, SequelizeStorage  } = require('umzug');
const db = require('../sequelize')
const { User } = require('../../models/models')
const bcrypt = require("bcrypt");

async function pingDb() {
    try {
        db.authenticate()
            .then(() => {
                console.log('Connection has been established successfully.');
            })
            .catch(err => {
                console.error('Unable to connect to the database:', err);
            });
    } catch (e) {
        console.error(`Error connection to db: ${e.message}`);
    }

}
// async function runMigration(migrationFile) {
//     const umzug = new Umzug({
//         migrations: {
//             // Шаблон для файлов миграций
//             glob: path.join(__dirname, 'migrations', '*.js'),
//             // Способ разрешения миграции для выполнения конкретных методов up/down
//             resolve: ({ name, path }) => {
//                 if (!migrationFile || name === migrationFile) {
//                     const migration = require(path);
//                     return {
//                         name,
//                         up: async () => migration.up(db.getQueryInterface(), db),
//                         down: async () => migration.down(db.getQueryInterface(), db),
//                     };
//                 }
//             },
//         },
//         context: db.getQueryInterface(),
//         storage: new SequelizeStorage({ sequelize: db }), // Хранилище для миграций
//         logger: console, // Логирование
//     });
//
//     try {
//         await umzug.up();
//         console.log(`Migration ${migrationFile} has been run successfully.`);
//     } catch (error) {
//         console.error(`Error running migration: ${error.message}`);
//     }
// }'

async function create_super_admin() {
    try {
        const user = {
            email: process.env.SUPERADMIN_EMAIL,
            pass: process.env.SUPERADMIN_PASSWORD,
            name: 'ADMINISTRATOR',
            role: process.env.SUPERADMIN_ROLE
        }

        console.log('\n\n\n\n USER', user, '\n\n\n\n')

        const hashPassword = await bcrypt.hash(user.pass, 6)
        const super_admin = await User.create(
            {
                email: user.email,
                password: hashPassword,
                name: user.name,
                role: user.role
            }
        )
        console.log('\n\n\n\n super_admin', super_admin, '\n\n\n\n')
    } catch (e) {
        console.error('Error super admin creating', e)
    }
}

// (async function () {
//     await pingDb()
//     await create_super_admin()
//     // await runMigration(path.join(__dirname, 'create_super_admin.js'),);
// })()
module.exports = create_super_admin

