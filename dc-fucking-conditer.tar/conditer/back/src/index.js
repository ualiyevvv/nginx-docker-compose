require('dotenv').config()
const cors = require('cors')
const logger = require('./logger/winstonLogger')
const sequelize = require('./database/sequelize')
const cookieParser = require('cookie-parser')
const errorHandling = require('./middleware/errorMiddleware')
const express = require('express')
const app = express()
const PORT = process.env.PORT || 3000

const CLIENT_URL = process.env.CLIENT_URL

app.use(cookieParser())
app.use(express.json())
app.use(cors({
    credentials: true,
    origin: CLIENT_URL
}))
// app.use(cors({
//     credentials: true,
//     origin: 'https://sprightly-squirrel-e59cbf.netlify.app',
// }))

const routes = require('./routes/routes')
const {User} = require("./models/models");
app.use('/api', routes)
app.use(errorHandling)

app.listen(PORT, () => {
    logger.info(`Server is running on port ${PORT}`)
})

// const ngrok = require('ngrok')
// app.listen(PORT, (err) => {
//     if(err) return console.log(err.message)
//     console.log(`App is running on port ${PORT}`)
//     ngrok.connect()
//         .then(url => console.log(url))
//         .catch(err => console.log(err.message))
// })

const start = async () => {
    try {

        await sequelize.authenticate()
        await sequelize.sync()

        const create_super_admin = require('./database/migrations/run_migrations')
        await create_super_admin()
        const {User} = require('./models/models')
        const allusers = await User.findAll()
        console.log('\n\n\n\n', allusers, '\n\n\n\n')

    } catch (e) {
        logger.error(`Error: ${e}`)
    }
}

const onGracefulShutDown = (signal) => {
    logger.error(`${signal} signal received`)
    app.close(() => {
        logger.error(`Closed out remaining connections`)
        process.exit(0)
    })
}

start()
process.on('SIGINT', () => onGracefulShutDown('SIGINT'))
process.on('SIGTERM', () => onGracefulShutDown('SIGTERM'))