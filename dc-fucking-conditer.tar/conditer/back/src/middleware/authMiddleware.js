const ApiError = require('../exceptions/ApiError')
const tokenService = require('../services/tokenService');

module.exports = function (roles=[]) {
    // if (req.method === "OPTIONS") {
    //     next()
    // }
    return function (req, res, next) {
        try {
            const authorizationHeader = req.headers.authorization

            if (!authorizationHeader) {
                return next(ApiError.unauthorizedRequest());
            }
            const accessToken = authorizationHeader.split(' ')[1];
            if (!accessToken) {
                return next(ApiError.unauthorizedRequest());
            }

            // TODO можно ли подделать jwt и енжектить нужную нам роль??
            const userData = tokenService.validateAccessToken(accessToken);
            console.log(`\n\n\n`, userData,`\n\n`)
            if (!userData) {
                return next(ApiError.unauthorizedRequest());
            }

            req.user = userData;

            if (roles.length > 0) {
                // check user role
                let hasRole = false
                if (roles.includes(userData.role)) {
                    hasRole = true
                }
                if (!hasRole) {
                    return res.status(403).json({error: "Invalid credentials"})
                }
            }

            next();
        } catch(e) {
            return next(ApiError.unauthorizedRequest());
        }
    }
}