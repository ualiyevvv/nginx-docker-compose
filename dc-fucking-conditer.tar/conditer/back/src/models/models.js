const sequelize = require('../database/sequelize')
const {DataTypes} = require('sequelize')

const VerfCodes = sequelize.define('verfcode', {
    id : {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    email: {type: DataTypes.STRING, allowNull: false},
    code: {type: DataTypes.STRING, allowNull: false},
    isActive: {type: DataTypes.BOOLEAN, defaultValue: true}
})

const Token = sequelize.define('token', {
    id : {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    refreshToken: {type: DataTypes.TEXT, allowNull: false},
})

const User = sequelize.define('user', {
    id : {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    name: {type: DataTypes.STRING},
    email: {type: DataTypes.STRING, unique: true, allowNull: false},
    email_confirmed: {type: DataTypes.DATE},
    password: {type: DataTypes.STRING},
    role: {type: DataTypes.STRING, defaultValue: "employee"},
})


User.hasMany(Token)
Token.belongsTo(User)

module.exports = {
    User,
    VerfCodes,
    Token,
}