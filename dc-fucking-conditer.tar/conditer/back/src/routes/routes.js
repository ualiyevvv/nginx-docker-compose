const {Router} = require('express')

const authMiddleware = require("../middleware/authMiddleware");

const router = new Router()
const profileRouter = require('./profileRouter')
const authRouter = require('./authRouter')

router.use('/profile', profileRouter)
router.use('/auth', authRouter)

module.exports = router
