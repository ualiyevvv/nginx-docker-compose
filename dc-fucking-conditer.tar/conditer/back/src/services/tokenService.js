const jwt = require('jsonwebtoken')
const {Token} = require('../models/models')
const ApiError = require('../exceptions/ApiError');
class TokenService {
    generateToken(payload) {
        const accessToken = jwt.sign(payload, process.env.SECRET_KEY, {expiresIn: '30m'})
        const refreshToken = jwt.sign(payload, process.env.SECRET_KEY, {expiresIn: '30d'})

        return {
            accessToken,
            refreshToken
        }

    }

    async saveToken(userId, refreshToken) {
        const tokenData = await Token.findOne({where: {userId}})
        if (tokenData) {
            tokenData.refreshToken = refreshToken;

            return tokenData.save();
        }

        return await Token.create({userId, refreshToken});
    }

    async removeToken(refreshToken){
        if (!refreshToken) {
            throw ApiError.badRequest('Refresh token does not exist', [])
        }
        return await Token.destroy({where: {refreshToken}});
    }

    validateRefreshToken(token) {
        try {
            return jwt.verify(token, process.env.SECRET_KEY);
        } catch (e) {
            return null;

        }
    }

    validateAccessToken(token) {
        try {
            return jwt.verify(token, process.env.SECRET_KEY);
        } catch (e) {
            return null;

        }
    }

    async findToken(refreshToken) {
        return await Token.findOne({where: {refreshToken}});
    }

}

module.exports = new TokenService();