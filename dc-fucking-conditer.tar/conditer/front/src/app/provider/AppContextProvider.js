import React, { createContext, useContext, useState } from 'react';
import useAuth from "./hooks/useAuth";
import useAdmin from "./hooks/useAdmin";

const AppContext = createContext();

export function useAppContext() {
    return useContext(AppContext);
}

export function AppContextProvider({ children }) {

    const authHandler = useAuth();
    const adminHandler = useAdmin();

    return (
        <AppContext.Provider
            value={{
                authHandler,
                adminHandler,
            }
        }>
            {children}
        </AppContext.Provider>
    );
}
