import React from "react";
import styles from './EmployeeCard.module.css'
import {Button, Link, Typography} from "../../../shared/ui";
import DeleteIcon from '../../../shared/assets/icons/delete_24dp_FILL0_wght400_GRAD0_opsz24.svg'
import {useAppContext} from "../../../app/provider/AppContextProvider";
import {EmployeeDelete} from "../../../features/employee/delete/EmployeeDelete";
import useToggle from "../../../shared/hooks/useToggle";
import {EmployeeUpdate} from "../../../features/employee/update/EmployeeUpdate";
export function EmployeeCard({ data }) {

    const [isEmployeeDelete, toggleEmployeeDelete] = useToggle()
    const [isEmployeeUpdate, toggleEmployeeUpdate] = useToggle()

    return (<>

        {isEmployeeDelete && <EmployeeDelete employeeId={data.id} onClose={toggleEmployeeDelete}/>}
        {isEmployeeUpdate && <EmployeeUpdate data={data} employeeId={data.id} onClose={toggleEmployeeUpdate} />}

        <div className={styles.EmployeeCard}>
            <div className={styles.EmployeeCard__fio}>
                <Typography size={16} weight={400} text={data.name}/>
            </div>

            <div className={styles.EmployeeCard__tools}>
                <Link text={'Изменить'} size={16} onClick={toggleEmployeeUpdate} />
                <Button onClick={toggleEmployeeDelete} isIconic={true}> <DeleteIcon/> </Button>
            </div>
        </div>
    </>)
}