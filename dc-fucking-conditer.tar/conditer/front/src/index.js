import React from 'react';
import ReactDOM from 'react-dom/client';
import {BrowserRouter} from "react-router-dom";

import App from "./app/App";

import env from "../.env.json";
console.log("process.env.API_URL:", process.env.API_URL_DEV);

// Таким же способом можно динамически менять иконку сайта
document.querySelector('[rel=icon]').href = `${process.env.API_URL_DEV}/favicon.ico`;


const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
    <BrowserRouter>
        <App />
    </BrowserRouter>
);

/*
▄───▄
█▀█▀█
█▄█▄█
─███──▄▄
─████▐█─█
─████───█
─▀▀▀▀▀▀▀
*/