import React from "react";
import Header from "../widgets/Header/Header";
// import {Box} from "../shared/ui";
import Navigation from "../widgets/Navigation/Navigation";
import {BottomNavigation} from "../shared/ui/navigation/BottomNavigation/BottomNavigation";
import useAdaptive from "../shared/hooks/adaptive/useAdaptive";

export default function AppContainer({children}) {

    const { device } = useAdaptive()

    return (<>
        {/*<Header />*/}
        {children}

        {/*{(device === 'mobile' || device === 'tablet') &&*/}
            <BottomNavigation>
                <Navigation notifications={[]} />
            </BottomNavigation>
        {/*}*/}
    </>)
}