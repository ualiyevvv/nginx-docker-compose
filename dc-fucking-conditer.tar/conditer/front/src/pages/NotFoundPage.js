import React from "react";
import {Box} from "../shared/ui";

export default function NotFoundPage() {
    return(<Box isHorizontalCenter isVerticalCenter>
        <h1>Not Found</h1>

        {/*<Block isAlignCenter={true} isCenteredByY={true}>*/}
        {/*    <Typography size={28} weight={700}>404 Page Not Found</Typography>*/}
        {/*</Block>*/}
    </Box>)
}