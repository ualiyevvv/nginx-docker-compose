import React from "react";
import styles from './Button.module.css'
export function Button({
    type='button',
    disabled=false,
    onClick=f=>f,
    children,
    width='100%',
    marginTop=0,
    marginBottom=0,
    isIconic=false,
    borderRadius=6,
    variant='',
                           top = 0
}) {

    marginTop = marginTop || top

    return (<>
        <button
            className={`
                ${styles.Button}
                ${disabled && styles['Button--disabled']}
                ${isIconic && styles['Button--isIconic']}
                ${variant === 'third' && styles['Button--third']}
                ${variant === 'clear' && styles['Button--clear']}
                ${variant === 'cancel' && styles['Button--cancel']}
            `}
            children
            style={{
                width,
                marginTop,
                marginBottom,
                borderRadius
            }}
            disabled={disabled}
            onClick={onClick}
            type={type}
        >
            {children}
        </button>
    </>)
}