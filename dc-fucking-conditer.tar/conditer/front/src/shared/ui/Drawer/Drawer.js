import React from "react";
import styles from "./Drawer.module.css";
import BackIcon from "../../assets/icons/Property 1=arrow.svg";

const RotatedIcon = ({ angle, Icon }) => {
    return <div className={styles.Drawer__header__expand_icon} style={{rotate: `${angle}deg`}}><BackIcon /></div>
}

export function Drawer({ isExpanded=false, title='', children, toggle=f=>f }) {

    return(<div className={`
        ${styles.Drawer}
        ${isExpanded && styles['Drawer--expanded']}
    `}>

        <div className={styles.Drawer__header}>
            <div className={styles.Drawer__header__title}>
                {title}
            </div>
            <span className={styles.Drawer__header__expand} onClick={toggle}>
                { isExpanded ? <RotatedIcon angle={270} /> : <RotatedIcon angle={90} icon={BackIcon} />}
            </span>
        </div>

        {isExpanded && <div className={styles.Drawer__content}>
            {children}
        </div>}

    </div>)
}