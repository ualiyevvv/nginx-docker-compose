import React, {useState} from "react";

import styles from './Input.module.css'
import EyeOffIcon from './icons/visibility_off_FILL0_wght400_GRAD0_opsz48.svg';
import EyeIcon from './icons/visibility_FILL0_wght400_GRAD0_opsz48.svg'

export function Input({
                          name='',
                          type='text',
                          value='',
                          placeholder='Input value',
                          required=false,
                          onChange=f=>f,
                          borderRadius=8,
                          onClick=f=>f,
                          onFocus=f=>f,
                          paddingLeft,
                          autocomplete
                      }) {

    const [_type, setType] = useState(type);
    function handleToggle() {
        if (type === 'password') {
            _type === 'password' ? setType('text') : setType('password');
        }
    }

    return (<div className={styles['input-wrapper']}>
        <input
            name={name}
            type={_type}
            placeholder={placeholder}
            value={value}
            onChange={onChange}
            required={required}
            className={styles.Input}
            style={{
                borderRadius,
                paddingLeft
            }}
            onClick={onClick}
            onFocus={onFocus}
            autoComplete={autocomplete}
        />
        {type === 'password' && <>
            <span className={styles['input-icon']} onClick={handleToggle}>
                {_type === 'password' ? <EyeOffIcon/> : <EyeIcon/>}
            </span>
        </>}
    </div>)
}