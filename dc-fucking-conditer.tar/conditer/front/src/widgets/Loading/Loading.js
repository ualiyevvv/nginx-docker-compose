import React from "react";
import {Loader, Overlay} from "../../shared/ui";


export function Loading(){
    return (<>
        <Overlay>
            {/*<Block isAlignCenter={true}>*/}
                <Loader color={'white'}/>
            {/*</Block>*/}
        </Overlay>
    </>);
}