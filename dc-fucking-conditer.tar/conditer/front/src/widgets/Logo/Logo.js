import React from "react";

export function Logo() {

    return (<>
        {/*LOGO*/}
    </>)
}