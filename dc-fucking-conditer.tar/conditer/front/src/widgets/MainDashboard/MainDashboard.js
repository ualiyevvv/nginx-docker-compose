import React from "react";
import {Block, Typography} from "../../shared/ui";
import {ProfileInfo} from "../../entities/profile/info/ProfileInfo";

export function MainDashboard({data}) {

    return(<>
        <Block marginBottom={20}>
            <Typography size={24} weight={700} text={'Общая информация'}/>
            <Typography size={16} weight={400} marginTop={2} text={'Ваши персональные данные'}/>
        </Block>

        <ProfileInfo data={data} />
    </>)
}