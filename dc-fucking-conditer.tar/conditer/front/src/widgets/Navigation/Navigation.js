import React, {useEffect} from 'react'
import styles from './Navigation.module.css'
import {useLocation, useNavigate} from "react-router-dom";
import {NavigationAction} from "../../shared/ui";

import MainIcon from '../../shared/assets/icons/Property 1=sth.svg'
import OptionsIcon from '../../shared/assets/icons/Property 1=options menu.svg'
import ProfileIcon from '../../shared/assets/icons/Property 1=profile.svg'
import CartIcon from '../../shared/assets/icons/Property 1=new.svg'
import {useAppContext} from "../../app/provider/AppContextProvider";
import useToggle from "../../shared/hooks/useToggle";
import LogoutForm from "../../features/auth/logout/LogoutForm";
const EmojiIcon = ({emoji}) => {
    return <span style={{fontSize: 24}}>{emoji}</span>
}
export default function Navigation({ notifications=[] }) {

    const navigate = useNavigate();
    const { pathname } = useLocation();

    const { authHandler } = useAppContext()
    const { user } = authHandler

    useEffect(() => {
        console.log('DATA USER', user)
    }, [user]);

    const [ isLogoutModalToggleActive, logoutModalToggle ] = useToggle()

    if (!user) {
        return
    }

    return (<>
        { isLogoutModalToggleActive && <LogoutForm onClose={logoutModalToggle}/>}
        <NavigationAction number_of_notifications={0} label='Главная' icon={<MainIcon />} active={pathname === '/'} onClick={e => navigate('/', {replace: true,})}  />
        {
            user?.role === 'super_admin' &&
            <NavigationAction number_of_notifications={0} label='Сотрудники' icon={<ProfileIcon />} active={pathname.startsWith('/employees')} onClick={e => navigate('/employees', {replace: true,})}  />
        }
        {/*<NavigationAction number_of_notifications={[].length} label='Cart' icon={<CartIcon />} active={pathname.startsWith('/cart')} onClick={e => navigate('/cart', {replace: true,})}  />*/}
        <NavigationAction number_of_notifications={0} label='Выйти' icon={<OptionsIcon />} active={pathname.startsWith('/profile')} onClick={logoutModalToggle}  />
    </>)
}