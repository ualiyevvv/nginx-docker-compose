const path = require("path");
const HtmlWebpackPlugin = require('html-webpack-plugin');
const Dotenv = require('dotenv-webpack');

const { API_URL, PORT } = process.env;
console.log('PORT', PORT);
console.log('API_URL', API_URL);


module.exports = {
    // Точку входа для сборки дерева модулей
    entry: "./src/index.js",

    // Webpack будет собирать все файлы в bundle.js
    output: {
        filename: "bundle.js",
        // Путь к папке, в которой будет находиться bundle.js
        path: path.resolve(__dirname, './build'),
        publicPath: '/'
    },

    // Работа с модулями
    module: {
        // Определяем правила для обработки файлов
        rules: [
            {
                // Регулярное выражение для обработки файлов с расширениями .js и .mjs
                test: /\.m?js$/,
                exclude: /node_modules/,
                loader: "babel-loader",
                options: {
                    /* Пресеты для преобразования кода:
                     * @babel/preset-env - преобразование JS
                     * @babel/preset-react - преобразование JSX
                     * */
                    presets: ['@babel/preset-env', "@babel/preset-react"],
                }
            },

            /* Interesting CSS and CSS Modules */
            {
                // Регулярное выражение для обработки файлов с расширениями .css и .scss
                test: /\.(css|scss)$/,
                use: [
                    'style-loader',
                    {
                        loader: 'css-loader',
                        options: {
                            importLoaders: 1,
                            modules: {
                                localIdentName: "[name]__[local]___[hash:base64:5]",
                            },
                        }
                    }
                ],
                // Применяем это правило только к файлам с .module.css в имени
                include: /\.module\.css$/
            },
            {
                test: /\.(css|scss)$/,
                use: [
                    'style-loader',
                    'css-loader'
                ],
                // Исключаем файлы с .module.css в имени
                exclude: /\.module\.css$/
            },


            {
                // Регулярное выражение для обработки файлов с расширением векторных файлов с расширением .svg
                test: /\.svg$/,
                use: ['@svgr/webpack'],
            },

            {
                // Регулярное выражение для обработки изображений с расширением .png и .jpeg/.jpg
                test: /\.(png|jpe?g)$/i,
                use: [
                    {
                        loader: 'file-loader'
                    }
                ]
            },

        ]
    },

    // Подключаем плагины
    plugins: [
        new Dotenv(),

        // Создаем entry HTML-файл на основе шаблона и подключаем в него bundle.js
        new HtmlWebpackPlugin({
            template: "./public/index.html"
        }),
    ],

    // Настройки webpack-dev-server
    devServer: {
        compress: true, // Сжатие для всех исходящих данных
        port: PORT || 9000, // Порт, на котором будет работать сервер
        allowedHosts: "all", // Позволяет принимать запросы со всех IP
        // Прокси - перенаправление запросов
        historyApiFallback: true, // Входит через index.html и дальше маршрутизируется ('/any' теперь работает).
        // proxy: [
        //     {
        //         context: ['/'], // Перенаправляем все запросы, начинающиеся с /api
        //         target: API_URL || 'http://localhost:3000', // Целевой сервер для прокси
        //         // changeOrigin: true,
        //         // "secure": false, // Проверку SSL сертификата
        //     }
        // ],
    }
};